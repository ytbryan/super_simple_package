# super_simple_package


## How to build 

```
pip uninstall super_simple_package
pip install -e .
```

## Run compilation

```
python3 setup.py sdist bdist_wheel
```